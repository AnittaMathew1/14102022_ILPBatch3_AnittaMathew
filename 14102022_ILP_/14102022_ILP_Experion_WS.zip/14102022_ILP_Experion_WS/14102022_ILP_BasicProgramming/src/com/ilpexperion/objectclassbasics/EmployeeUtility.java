package com.ilpexperion.objectclassbasics;

public class EmployeeUtility {

	public static void main(String[] args) {
		Employee employee = new Employee(); //Classname referencevariable= new objectname()
		//referencevaeraiable points to object
		
		employee.displayEmployeeDetails();

	}

}
