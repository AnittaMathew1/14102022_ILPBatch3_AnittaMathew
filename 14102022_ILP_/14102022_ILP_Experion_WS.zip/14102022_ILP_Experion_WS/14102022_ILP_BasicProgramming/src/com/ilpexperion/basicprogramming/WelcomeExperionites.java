package com.ilpexperion.basicprogramming;

public class WelcomeExperionites {

	public static void main(String[] args) {
		System.out.println("Welcome to ILP Program Day 1");

	}

}
