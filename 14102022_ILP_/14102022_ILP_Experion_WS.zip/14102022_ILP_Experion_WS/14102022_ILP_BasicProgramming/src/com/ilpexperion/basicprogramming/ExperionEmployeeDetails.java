package com.ilpexperion.basicprogramming;

public class ExperionEmployeeDetails {

	public static void main(String[] args) {
		String trainingName="welcome";
		String employeeName;
		int employeeAge;
		char employeeGender;
		double employeeCgpa;
		
		
		System.out.println("Name"+ "   " + "Age"   + "Gender"  +"cgpa");//+used for concatenation
	    System.out.println(employeeName+"   "+employeeAge+"   "+employeeGender+"   "+employeeCgpa);
		
		

	}

}
