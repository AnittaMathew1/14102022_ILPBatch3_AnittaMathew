package com.ilpexperion.basicprogramming;

public class DisplayOutput {

	public static void main(String[] args) {
		
		String heading;
		heading = "********Welcome to ILP Program***********";
		System.out.println(heading);
		
		String name;
		System.out.println("Name");
		name= "Anjima Sadasivan";
		System.out.print(name);
		
		int age;
		System.out.print("Age");
		age= 22;
		System.out.print(age);
		
		double cgpa;
		System.out.print("CGPA");
		cgpa = 8.6;
		System.out.println(cgpa);
		
		
		

	}

}
