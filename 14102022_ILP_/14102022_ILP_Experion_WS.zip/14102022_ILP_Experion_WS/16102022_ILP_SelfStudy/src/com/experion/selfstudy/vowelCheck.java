package com.experion.selfstudy;

import java.util.Scanner;

public class vowelCheck {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		char alphabet= scanner. next().charAt(0);
		switch(alphabet)
		{
		case 'a':{
			System.out.print("Its a vowel");
			break;
		}
		case 'e':{
		System.out.print("Its a vowel");
		break;
			}
		case 'i':{
	System.out.print("Its a vowel");
	break;
			}
			case 'o':{
				System.out.print("Its a vowel");
				break;
				}
				case 'u':{
						System.out.print("Its a vowel");
						break;
						}
				default:{
					System.out.print("Its Not a vowel");
					}


		}
		}}


