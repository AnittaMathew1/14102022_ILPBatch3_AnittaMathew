package com.experion.selfstudy;

import java.util.Scanner;

public class sumoftwonos {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int firstNumber=0;
		int secondNumber=0;
		firstNumber=scanner.nextInt();
		secondNumber=scanner.nextInt();
		int sum = firstNumber+secondNumber;
		System.out.print("sum of numbers is: "+sum);
		

	}

}
