package com.experion.utility;

import com.experion.entity.Product;

public class ProductUtility {

	public static void main(String[] args) {
		Product product = new Product();
		product.inputProductDetails();
		product.displayProductDetails();
	}

}
