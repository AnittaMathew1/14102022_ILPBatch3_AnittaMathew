package com.experion.service;

public interface LoanServices {
	
	public abstract void checkValidity();
	public abstract void checkdueDate();
	public abstract void loanApproval();
	

}
