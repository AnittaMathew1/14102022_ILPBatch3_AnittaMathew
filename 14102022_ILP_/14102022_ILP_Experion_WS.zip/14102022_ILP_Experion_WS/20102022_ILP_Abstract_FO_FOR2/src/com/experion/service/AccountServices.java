package com.experion.service;

public interface AccountServices {

	
	public abstract void  cashWithdraw();
	public void checkBalance();
	
	
		


		
	}


