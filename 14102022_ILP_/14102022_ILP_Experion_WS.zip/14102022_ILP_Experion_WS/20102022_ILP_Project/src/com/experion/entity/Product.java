package com.experion.entity;

public class Product {
	private String productCode;
	private String productName;

}
