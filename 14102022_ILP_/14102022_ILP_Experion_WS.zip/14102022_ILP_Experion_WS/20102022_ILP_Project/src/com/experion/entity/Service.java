package com.experion.entity;

public class Service {
	private String serviceName;

}
