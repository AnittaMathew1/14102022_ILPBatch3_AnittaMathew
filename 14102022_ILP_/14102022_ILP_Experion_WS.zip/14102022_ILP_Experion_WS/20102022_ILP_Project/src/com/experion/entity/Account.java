package com.experion.entity;

public class Account {

}
