package com.experion.service;

import java.util.ArrayList;

public class BankService {
	
	public ArrayList<Services>createServices(){
		ArrayList<Services>allServiceList=new ArrayList<Services>();
		allServiceList.add(new Service("Cash deposit"));
		
		return allServiceList;
		
	}
	
	public ArrayList<Product>createProducts(A){
		ArrayList<Services>allServiceList=new ArrayList<Services>();
		
		
		return productList;
		
	}

}
