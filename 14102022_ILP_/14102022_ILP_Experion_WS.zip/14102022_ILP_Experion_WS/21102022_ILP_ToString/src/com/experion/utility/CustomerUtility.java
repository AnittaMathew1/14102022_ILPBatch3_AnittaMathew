package com.experion.utility;

import com.experion.entity.Customer;

public class CustomerUtility {

	public static void main(String[] args) {
		Customer customer = new Customer("AAA","HHH");
		System.out.println(customer);

	}

}
