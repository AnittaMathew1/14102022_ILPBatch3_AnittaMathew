package com.ilpexeprion.basicprogramming;

public class ExperionEmployeeDetails {

	public static void main(String[] args) {

		String trainingName = "*****************  Welcome to ILP Program **************************";
		String employeeName = "Suneesh";
		int employeeAge = 36;
		char employeeGender = 'M';
		double employeeCgpa = 8.5;
		System.out.println(trainingName);
		System.out.println("Name" + "	 " + "Age" + "	 " + "Gender" + "	 " + "CGPA");
		System.out.println(employeeName + "	 " + employeeAge + "	 " + employeeGender + "	 " + employeeCgpa);

	}

}
