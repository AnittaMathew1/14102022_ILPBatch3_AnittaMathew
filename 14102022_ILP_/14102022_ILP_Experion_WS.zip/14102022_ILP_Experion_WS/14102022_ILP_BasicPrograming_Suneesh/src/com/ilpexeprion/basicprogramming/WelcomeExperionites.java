package com.ilpexeprion.basicprogramming;

public class WelcomeExperionites {

	public static void main(String[] args) {
		
		System.out.println("Wecome to ILP Program Day 1");
		

	}

}
